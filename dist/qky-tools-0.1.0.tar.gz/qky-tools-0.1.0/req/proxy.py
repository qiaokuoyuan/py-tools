import requests
import typing


def get_one_text_xun_dai_li_proxy_ip(api: str):
    ...


def get_one_json_xun_dai_li_proxy_ip(api: str):
    ...


def proxy_request():
    ...
